// script.js
document.addEventListener('mousemove', function(event) {
    const snowflake = document.createElement('div');
    snowflake.classList.add('snowflake');
    document.querySelector('.snow').appendChild(snowflake);

    // Đặt vị trí bông tuyết ở vị trí của con trỏ chuột
    snowflake.style.left = `${event.pageX}px`;
    snowflake.style.top = `${event.pageY}px`;

    // Tạo hiệu ứng rơi với thời gian ngẫu nhiên
    const size = Math.random() * 10 + 5; // Kích thước bông tuyết
    snowflake.style.width = `${size}px`;
    snowflake.style.height = `${size}px`;
    snowflake.style.opacity = Math.random() * 0.8 + 0.2;

    // Thay đổi thời gian hoạt ảnh dựa trên kích thước bông tuyết
    const animationDuration = Math.random() * 3 + 2; // Thời gian rơi từ 2s đến 5s
    snowflake.style.animationDuration = `${animationDuration}s`;

    // Xóa bông tuyết sau khi hoạt ảnh hoàn tất
    setTimeout(() => {
        snowflake.remove();
    }, animationDuration * 1000); // Thay đổi thời gian nếu cần
});